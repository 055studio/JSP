package cs.dit.dao;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import cs.dit.dto.BoardDTO;

public class BoardDAO {
   private static SqlSessionFactory sqlMapper = null;
   
      public static SqlSessionFactory getInstance() {
         if (sqlMapper == null) {
            try {
               InputStream inputStream = Resources.getResourceAsStream("cs/dit/dao/mybatis-config.xml");
               sqlMapper = new SqlSessionFactoryBuilder().build(inputStream);
               inputStream.close();
            }catch(Exception e) {
               e.printStackTrace();
            }
         }
         return sqlMapper;
      }
      
      public List<BoardDTO> list() {
         sqlMapper = getInstance();
         
         SqlSession session = sqlMapper.openSession();
         
         try {
            return session.selectList("cs.dit.dao.selectAll");
         } finally {
            session.close();
         }
         
      }
      
      public BoardDTO view(String bcode) {
         sqlMapper = getInstance();
         SqlSession session = sqlMapper.openSession();
         
         try {
            return session.selectOne("cs.dit.dao.selectOne", bcode);
         } finally {
            session.close();
         }
      }
        public int insert(BoardDTO dto) { 
            sqlMapper = getInstance();
            SqlSession session = sqlMapper.openSession();
            try {
               int i = session.selectOne("cs.dit.dao.insert", dto);
               session.commit();
               return i;
            } finally {
               session.close();
            }
         }        
        public int update(BoardDTO dto) {
            sqlMapper = getInstance();
            SqlSession session = sqlMapper.openSession();
            try {
               int i = session.selectOne("cs.dit.dao.update", dto);
               session.commit();
               return i;
            } finally {
               session.close();
            }
         }   
        public int delete(String bcode) { 
            sqlMapper = getInstance();
            SqlSession session = sqlMapper.openSession();
            try {
               int i = session.selectOne("cs.dit.dao.delete", bcode);
               session.commit();
               return i;
            } finally {
               session.close();
            }
         }   
   }