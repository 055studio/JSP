package cs.dit.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.dit.dao.ReplyDAO;
import cs.dit.dto.ReplyDTO;

@WebServlet("*.reply")
public class ReplyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		ReplyDAO dao = new ReplyDAO();
		ReplyDTO dto = new ReplyDTO();
		String viewPage =null;
		
		String uri = request.getRequestURI(); 	//uri :/member-mvc/insert.do
		String com= uri.substring(uri.lastIndexOf("/")+ 1, uri.lastIndexOf(".reply")); //command :insert
		
		if(com !=null && com.trim().equals("rlist")) {
			List<ReplyDTO> dtos = dao.rlist();
			request.setAttribute("rlist", dtos);
			viewPage = "/WEB-INF/view/bList.jsp";
			
		}else if(com !=null && com.trim().equals("rinsert")) {
			dto.setBoardNum(request.getParameter("boardNum"));
			dto.setReplyContent(request.getParameter("content"));
			dao.rinsert(dto);
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(viewPage);
		rd.forward(request, response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}

}
