package cs.dit.dao;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import cs.dit.dto.BoardDTO;

public class BoardDAO {
   private static SqlSessionFactory sqlMapper = null;
   
      public static SqlSessionFactory getInstance() {
         if (sqlMapper == null) {
            try {
               InputStream inputStream = Resources.getResourceAsStream("cs/dit/dao/mybatis-config.xml");
               sqlMapper = new SqlSessionFactoryBuilder().build(inputStream);
               inputStream.close();
            }catch(Exception e) {
               e.printStackTrace();
            }
         }
         return sqlMapper;
      }
      
      public List<BoardDTO> list() {
         sqlMapper = getInstance();
         
         SqlSession session = sqlMapper.openSession();
         
         try {
            return session.selectList("cs.dit.dao.selectAll");
         } finally {
            session.close();
         }
         
      }
      
      public BoardDTO view(String bcode) {
         sqlMapper = getInstance();
         SqlSession session = sqlMapper.openSession();
         
         try {
            return session.selectOne("cs.dit.dao.selectOne", bcode);
         } finally {
            session.close();
         }
      }
        public int insert(BoardDTO dto)  {
    		SqlSession session = sqlMapper.openSession();
    		//alert 창을 사용할 경우에는 succ를 return 해야한다.
    		//PrintWriter 이용한 script 코드로 구현한 후 페이지 전환 처리
    		int succ = 0;
    		succ = session.insert("cs.dit.dao.insert", dto);
    		session.commit();
    		session.close();
    		return succ;
    	} //boardInsert()
  
        public int update(BoardDTO dto) {
    		SqlSession session = sqlMapper.openSession();
    		//alert 창을 사용할 경우에는 succ를 return 해야한다.
    		//PrintWriter 이용한 script 코드로 구현한 후 페이지 전환 처리
    		int succ = 0;
    		succ = session.update("cs.dit.dao.update", dto);
    		session.commit();
    		session.close();
    		return succ;
    	}
        public int delete(String bcode) {
    		SqlSession session = sqlMapper.openSession();
    		//alert 창을 사용할 경우에는 succ를 return 해야한다.
    		//PrintWriter 이용한 script 코드로 구현한 후 페이지 전환 처리
    		int succ = 0;
    		succ = session.delete("cs.dit.dao.delete", bcode);
    		session.commit();
    		session.close();
    		return succ;
    	}   
   }