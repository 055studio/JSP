package cs.dit.dao;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import cs.dit.dto.ReplyDTO;

public class ReplyDAO {
	
	private static SqlSessionFactory sqlMapper;

	public static SqlSessionFactory getInstance() {
		if(sqlMapper == null) {
			try {
				InputStream inputStream = Resources.getResourceAsStream("cs/dit/dao/mybatis-config.xml");
				sqlMapper = new  SqlSessionFactoryBuilder().build(inputStream);
				inputStream.close();
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		return sqlMapper;
	}
	
	public List<ReplyDTO> rlist() {
		sqlMapper = getInstance();
		
		SqlSession session = sqlMapper.openSession();
		
		try {
			return session.selectList("cs.dit.replyDAO.selectAll");
		}finally {
			session.close();
		}
		
	}
	
	public int rinsert(ReplyDTO dto) {
		sqlMapper = getInstance();
		SqlSession session = sqlMapper.openSession();
		try {
			int succ = session.insert("cs.dit.replyDAO.insert", dto);
			session.commit();
			session.close();
			return succ;
		}finally {
			session.close();
		}
	}


}
